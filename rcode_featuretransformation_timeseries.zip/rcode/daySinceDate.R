
daySinceDate <- function(timestamp, reference_date){
  if(timestamp == "NULL") {
    return(-1)
  } else {
  toDate <- as.Date(reference_date)
  days <- toDate - as.Date(timestamp)
  return(abs(days))
  }
  
}


#x <- daySinceDate(as.Date("2016-04-01"))