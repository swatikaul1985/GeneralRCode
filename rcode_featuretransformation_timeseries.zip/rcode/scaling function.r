



function_mean_std <- function(pct,Var ) { # pct is percentile cutoff, Var is variable to be modified
  
                          var_thrs <- quantile(Var,probs = c(pct))
                          
                          df <- as.data.frame(Var)
                          
                          Var_Tr <-  df %>% select(Var) %>% filter(Var < var_thrs )
                          
                          mean_var_tr <- mean(Var_Tr[,1])
                          
                          stdev_var_tr <- sd(Var_Tr[,1])
                          
                          return(c(mean_var_tr,stdev_var_tr))
                          
                          }

scale_custom <-  function(x,mean, stdev) {
  
  y <- 0
  
  y <- (x-mean)/stdev
  return(y)
  
}



Modified_scaling <- function(df, pct){ # df is subset dataframe, mean_sd_df is mean and sd dataframe
  
  mod_df <- df
  
  Mod_mean_sd <- as.data.frame(apply(mod_df, 2, function(x) {function_mean_std(pct,x)}))
  
  for(i in 1:ncol(df))
  {
    
    mod_df[,i] <- scale_custom(df[,i],Mod_mean_sd[1,i],Mod_mean_sd[2,i])
    
  }
  return(mod_df)
}




# Usage.Data.v1 original dataset

# Usage.Data.v1 <- your_data 

# Usage.Data.v1.subset <- Usage.Data.v1 %>% select(# give variables used for clustering)
# )

#Usage.Data.v1.subset <- Usage.Data.v1[,-c(1:4)] # selecting onlu numeric variables to be used for clustering



#Subset_Usage.Data.v1_scaled <- Modified_scaling(Usage.Data.v1.subset ,0.99)

#Scaled_data <- Subset_Usage.Data.v1_scaled


