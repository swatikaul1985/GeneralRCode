


aggSubToCust <- function(Tele.data.cust,Dim.level,day,month,Var.list) {
  
  vec_fil1 <- c(Dim.level,day,month)
  
  vec_fil <- c(vec_fil1,Var.list)
  
  a <- Tele.data.cust %>% select(which(names(Tele.data.cust) %in% vec_fil))
  
  rm(Tele.data.cust)
  
 a[is.na(is.numeric(a[]))] <- 0
  
  # Start the clock!
  ptm <- proc.time()
  
  # Setting the up the cores
  
  cl = makeCluster(3)
  registerDoSNOW(cl)
  cat(paste(getDoParWorkers(),": Threads intiated!"))
  
  Tele.data.cust.daily <- 
    foreach(j=1:length(Var.list), .combine='cbind')  %dopar% {
      
      require(dplyr)
      
      var <- Var.list[j]
      
      fun <- get("sum");  
      
      a %>% select(which(names(a) %in% c(Dim.level,day,var))) %>% group_by(cloudcustomerguid,timestamp)%>% summarise_each(  funs(fun))
    }
  
  stopCluster(cl)
  # Stop the clock
  proc.time() - ptm
  
  rm(a)
  
  Tele.data.cust.daily <- Tele.data.cust.daily[, unique(colnames(Tele.data.cust.daily))]
  
  
    return(Tele.data.cust.daily)
  
  
}