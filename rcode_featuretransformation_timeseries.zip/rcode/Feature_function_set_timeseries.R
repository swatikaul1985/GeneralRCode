# 
# Functions	Explanation
# min	Minimum of the sequence
# max	Maximum of the sequence
# sd            	Standard deviation of the sequence
# mean	Mean of the sequence
# median                                   	Median of the sequence
# slope	Slope of the linear trend line from the sequence 
# zero_count	Count of zero values in the sequence
# zero_length	Number of consecutive zeros in the sequence
# tail_zeros	Number of consecutive zeros from the tail
# last_value	Last value of the sequence
# last_mean	Mean of the last 7 values in the sequence
# last_slope	Slope pf the last 7 values in the sequence
# sd_mean_ratio	Ratio of sd over mean of the sequence
# tail_head_ratio	Ratio of last value over first value in the sequence
# last_to_all_ratio	Ratio of last 7 values mean over mean for all 
# last_to_first_ratio	Ratio of last 7 values mean over first 7 values mean



# step count

step_count<- function(TS){ # TS is a sorted time series as a vector
  
  TS <-  as.vector(TS)
  
  TS1 <- sapply(TS, function(x) ifelse(x==0,0,1))
  
  n=1
  
  
  for (i in 1:(length(TS1)-1)) {
    
    
    n = ifelse(TS1[i] == TS1[i+1],n,n+1)
    
  }
  
  n = ifelse(sum(TS1) ==0 ,0,n)
  
  return(ifelse(n==1,1,floor(n/2)))
  
}


activity_ratio <- function(TS){ # TS is a sorted time series as a vector
  
  TS <-  as.vector(TS)
  
  return(sum(TS!=0)/length(TS))
 
}

# count of zeros

zero_count <- function(x)
{
  x <- as.vector(x)
  sum(x==0)
}


# last value
last_value <- function(x)
{
  x <- as.vector(x)
  tail(x,1)
}

# sd to meam ratio
sd_mean_ratio <- function(x)
{
  if(mean(x)==0)
    return(-1)
  else
    return(sd(x)/mean(x))
}






# ratio

ratio <- function(x,y)
{
  m <- x/y
  m[is.nan(m)] <- -1
  m[is.infinite(m)] <- -1
  return(m)
}




# average of last m points
last_mean <- function(x)
{
  m=7
  return(mean(tail(x,m)))
}

# lastValue/first_value
tail_head_ratio <- function(x)
{
  if(head(x,1)==0)
    return(-1)
  else
    return(tail(x,1)/head(x,1))
  
}

# max count of consecutive 0 values
zero_length <- function(x)
{
  r <- rle(x)
  if(sum(r$values==0)==0)
    return(0)
  else
    return(max(r$length[r$values == 0])) 
}

# tail zero length
tail_zeros <- function(x)
{
  r <- rle(x)
  if(tail(r$values,1)==0)
    return(r$length[length(r$values)])
  else
    return(0)
}

# last mean to overall mean ratio
last_to_all_ratio <- function(x)
{
  m=7
  if(mean(x)!=0)
    return(mean(tail(x,m))/mean(x))
  else
    return(-1)
}

#last mean to first mean ratio
last_to_first_ratio <- function(x)
{
  m=7
  if(mean(head(x,m))!=0)
    return(mean(tail(x,m))/mean(head(x,m)))
  else
    return(-1)
  
} 

slope <- function(y)
{
  n <- length(y)
  x <- 1:n
  l <- (n*sum(x*y)-sum(x)*sum(y)) / (n*sum(x^2)-sum(x)^2)
  return(l)
}

last_slope <- function(y)
{
  m <- 7
  n <- length(tail(y,m))
  x <- 1:n
  l <- (n*sum(x*tail(y,m))-sum(x)*sum(tail(y,m))) / (n*sum(x^2)-sum(x)^2)
  return(l)
}


min_ts <- function(y)
{
return(min(y))
}


max_ts <- function(y)
{
  
  return(max(y))
}


sum_ts <- function(y)
{
  
  return(sum(y,na.rm = T))
}

mean_ts <- function(y)
{
  
  TS <-  as.vector(y)
  
  return(sum(TS,na.rm = T)/length(TS[TS!=0]))
  
}

median_ts <- function(y)
{
  
  TS <-  as.vector(y)
  
  return(median(TS,na.rm = T))
  
}


std_dev <- function(y)
{
  
  return(sd(y,na.rm = T))
}


max_min <- function(y)
{
  
  return((max(y)- min(y)))
}


interQuartileRange <-  function(y)
{
  require(stats)
  return(IQR(y, na.rm = T, type = 7))
}


kurtosis_ts <-  function(y)
{
  require(moments)
  return(kurtosis(y,na.rm = T))
}


