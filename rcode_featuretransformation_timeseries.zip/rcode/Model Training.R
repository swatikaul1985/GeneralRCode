



Train_model <- function(df,Dim.level, feature.list, feature.list.scale = feature.list,pct,k , coderepo)
  
{




final.model.df <- df

#Scaling the customers

Usage.Data.v1 <- final.model.df %>% select( one_of(setdiff(feature.list, feature.list.scale)))

# 
# Usage.Data.v2 =  Usage.Data.v1 %>%
#  mutate_each(funs(scale))                
#   



 Usage.Data.v1.subset <- final.model.df %>% select(one_of(feature.list.scale))

source(paste0(coderepo,"\\scaling function.R"))

Subset_Usage.Data.v1_scaled <- Modified_scaling(Usage.Data.v1.subset ,pct)

Usage.Data.v2 <- as.data.frame(cbind(Usage.Data.v1,Subset_Usage.Data.v1_scaled))

cap <- function(x) {return(ifelse(abs(x)>3,ifelse(x>3,3,-3),x))}


Usage.Data.v3 <- as.data.frame(apply(Usage.Data.v2,2,cap))




######################################Function to implement the scree plot##########################
# 
# Function to implement the scree plot
plotParallelScree = 
  function (df, th, seedvector, prefix = ""){
    # Setting the up the cores
    cl = makeCluster(th)
    registerDoSNOW(cl)
    cat(paste(getDoParWorkers(),": Threads intiated!"))
    x = seedvector
    wss0 <- (nrow(df)-1)*sum(apply(df,2,var))  
    wss <- 
      foreach(j=1:length(x), .combine='cbind') %:%
      foreach(i=2:18, .combine = "c") %dopar% {
        set.seed(x[j]);  sum(kmeans(df, centers=i, iter.max = 65532)$withinss)
      }
    for(j in 1:length(x)){ 
      a = paste("Elbow Curve - Kmeans (seed = ",x[j],")", sep = "")
      png(file = paste(prefix,"Cluster_seed",x[j] ,"_oct_nov_dec.png",sep = ""), height=630, width = 864)
      plot(1:18, c(wss0,wss[,j]), main = a, type="b", xlab="Number of Clusters", ylab="Average within - cluster sum of squares",col = "royalblue")                                                                                                                                                                                               
      dev.off()
    } 
    stopCluster(cl)
    print(paste("Knee elbow plots created successfully at",getwd()))
    return (0)
  } 




#checking for optimal number of clusters

x = seq(2000, 2016, 2)
plotParallelScree(Usage.Data.v3, 4, x, prefix = "Iteration1")



#set.seed(2002)
#nc <- NbClust(Usage.Data.v3, min.nc=2, max.nc=8, method="kmeans")
#table(nc$Best.n[1,])

#k <- which.max(nc$Best.n[1,])

# gives the elbow curves
#k=8

set.seed(2016);

centers= kmeans(Usage.Data.v3, centers=k, iter.max = 15625)$centers

set.seed(2016);

Model <- kmeans(Usage.Data.v3, centers = k, iter.max = 15625)





#mod2 <- readRDS("mymodel.rds")
set.seed(2010);

Usage.Data.v3$ClusterId =  kmeans(Usage.Data.v3, centers=k, iter.max = 15625)$cluster  


final_cluster_map_customer <- as.data.frame(cbind(final.model.df , ClusterId = Usage.Data.v3$ClusterId))



# final.data <- final_cluster_map_customer %>% select(one_of(c("ClusterId",feature.list)))

#final.data$ServiceCount <- as.numeric(final.data$ServiceCount)
#final.data$DBCount <- as.numeric(final.data$DBCount)
# final.data$Logincount <- as.numeric(final.data$Logincount)
final_cluster_map_customer$ClusterId <- as.factor(final_cluster_map_customer$ClusterId)


# Getting the cluster definition    


###################################Function to create cluster defination table ###############################

source(paste0(coderepo,"\\Cluster_Summary.r"))

summary_object <- summary_cluster(final.data)


final.object <- list(Model,final.data,summary_object[1],summary_object[2])

return(final.object)


}


