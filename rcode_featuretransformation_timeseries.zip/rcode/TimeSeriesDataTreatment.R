#Treating time series to be in certain format


TimeSeries_Treatment <- function(date.mapping,Tele.data.cust.daily,Dim.level,day ) {
  

df1 <- date.mapping


df2 <- Tele.data.cust.daily

rm(Tele.data.cust.daily)

# inserting zeros for missing days

cust.list <- df2 %>% select(which(names(df2) %in% c(Dim.level))) %>% distinct

df3 <- merge(df1,cust.list)

rm(df1)


df3$calendardate <- as.Date(df3$calendardate)

df2$timestamp <- as.Date(df2$timestamp)

TS <- left_join(df3,df2,by = c("cloudcustomerguid" = "cloudcustomerguid","calendardate" = "timestamp"))



# sort time series

TS <- TS %>% arrange(cloudcustomerguid,calendardate)

# drops <- nonTS.list #c("Timestamp","DeploymentLastUpdated","DeploymentCreatedTime")

# TS <- TS[ , !(names(TS) %in% drops)]

TS[is.na(TS)] <- 0

Tele.data.cust.daily.treated <- TS

rm(TS)

return(Tele.data.cust.daily.treated)

}