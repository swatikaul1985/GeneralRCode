# user defined functions

factorTonum <- function(x){(as.numeric(x)-1)}

# dummy variable creation


# flag creation from yes or no type or ture/false type variables

