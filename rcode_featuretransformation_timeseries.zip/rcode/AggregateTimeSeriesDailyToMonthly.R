
# time series transformations

aggTS.DailyToMonthly <- function(Tele.data.cust.daily.treated,TS.list,timeseriesFunc.list,Dim.level,day,month) {
  
  source(paste0(rcoderepo,"\\Feature_function_set_timeseries.R"))
  
  vec_fil1 <- c(Dim.level)
  
  vec_fil <- c(vec_fil1,TS.list)
  
  a <- Tele.data.cust.daily.treated %>% select(which(names(Tele.data.cust.daily.treated) %in% vec_fil))
  
  rm(Tele.data.cust.daily.treated)
  
  # Start the clock!
  ptm <- proc.time()
  
  # Setting the up the cores
  library(foreach)
  cl = makeCluster(3)
  registerDoSNOW(cl)
  cat(paste(getDoParWorkers(),": Threads intiated!"))
  
  clusterExport(cl, timeseriesFunc.list,envir = .GlobalEnv)
  
  Tele.data.cust.ts <- 
    foreach(j=1:length(timeseriesFunc.list), .combine='cbind')  %dopar% {
      require(dplyr)
      fun <- get(timeseriesFunc.list[j])  
      
      b <-  a %>% group_by(cloudcustomerguid)%>% summarise_each(funs(fun))
      colnames(b)[-c(1)] <- paste(colnames(b)[-c(1)] ,timeseriesFunc.list[j],  sep = "_")
      b
    }
  
  stopCluster(cl)
  # Stop the clock
  proc.time() - ptm
  
  Tele.data.cust.ts <- Tele.data.cust.ts[, unique(colnames(Tele.data.cust.ts))]
  
  return(Tele.data.cust.ts)
}
