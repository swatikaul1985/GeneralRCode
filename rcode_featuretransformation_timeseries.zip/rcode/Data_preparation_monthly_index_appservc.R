


Pull_data <- function(Startdate,Enddate,teleTableName.index,SnapshottableObject.index, pairWiseAggFunc.SubToCUst.index,Dim.level,day,month,Var.list) 


{

 Tele.data.index <- teleTableName.index
 
 rm(teleTableName.index)
 
 
 Sub.Cust.mapping <- SnapshottableObject.index
 
  rm(SnapshottableObject.index)

# mapping daily telemetry data to customerid
  


Tele.data.index$subscriptionguid <- toupper(Tele.data.index$subscriptionguid)

Sub.Cust.mapping$subscriptionguid <- toupper(Sub.Cust.mapping$subscriptionguid)

# combine flag type vars

Tele.data.index[is.na(Tele.data.index)] <- 0

Tele.data.index$Feature_use_Count <-  (Tele.data.index$hasssl
                                    +Tele.data.index$hasslots
                                    +Tele.data.index$hasbackuprestore
                                    +Tele.data.index$hashybridconnections
                                    +Tele.data.index$haswebjobs
                                    +Tele.data.index$hassiteauth
                                    +Tele.data.index$hastip
                                    +Tele.data.index$hasvnet
                                    +Tele.data.index$usedremotedebugging
                                    +Tele.data.index$haswebsockets
                                    +Tele.data.index$haswatm
                                    +Tele.data.index$hascustomdomain)





 

Tele.data.cust <- inner_join(Sub.Cust.mapping,Tele.data.index)



names(Tele.data.cust) <- tolower(names(Tele.data.cust))

saveRDS(Tele.data.cust,paste0(ObjectSpace,"\\Tele.data.cust.rds"))



# aggregate time series data at customer day level

source(paste0(rcoderepo ,"\\AggregateSubToCustMonthly_Index.R"))


Final.cust.daily <- aggSubToCust(Tele.data.cust,pairWiseAggFunc.SubToCUst.index,Dim.level,day,month,Var.list.index)





return(Final.cust.daily)

}


