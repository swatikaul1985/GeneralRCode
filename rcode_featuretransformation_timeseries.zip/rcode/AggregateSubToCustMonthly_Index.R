


aggSubToCust <- function(Tele.data.cust,pairWiseAggFunc.SubToCUst.index,Dim.level,day,month,Var.list.index) {
  
  vec_fil1 <- c(Dim.level,month)
  
  vec_fil <- c(vec_fil1,Var.list.index)
  
  a <- Tele.data.cust %>% select(which(names(Tele.data.cust) %in% vec_fil))
  
  rm(Tele.data.cust)
  
  a[is.na(a)] <- 0
  
  # Start the clock!
  ptm <- proc.time()
  
  # Setting the up the cores
  
  cl = makeCluster(3)
  registerDoSNOW(cl)
  cat(paste(getDoParWorkers(),": Threads intiated!"))
  
  Tele.data.cust.monthly.index <- 
    foreach(j=1:length(pairWiseAggFunc.SubToCUst.index), .combine='cbind')  %dopar% {
      
      require(dplyr)
      
      var <- pairWiseAggFunc.SubToCUst.index[[j]][1]
      
      fun <- get(pairWiseAggFunc.SubToCUst.index[[j]][2]);  
      
      a %>% select(which(names(a) %in% c(Dim.level,var))) %>% group_by(cloudcustomerguid)%>% summarise_each(  funs(fun))
    }
  
  stopCluster(cl)
  # Stop the clock
  proc.time() - ptm
  
  
  rm(a)
  
  Tele.data.cust.monthly.index <- Tele.data.cust.monthly.index[, unique(colnames(Tele.data.cust.monthly.index))]
 
  # saveRDS(Tele.data.cust.monthly.index,paste0(ObjectSpace,"\\Tele.data.cust.monthly.index.rds"))
  
  return(Tele.data.cust.monthly.index)
  
  
}