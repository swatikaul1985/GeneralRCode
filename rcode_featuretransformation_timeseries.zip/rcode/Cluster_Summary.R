
summary_cluster <- function(final.data) {
  
  pt25 = function(x) {return (quantile(x, 0.25))}
  pt75 = function(x) {return (quantile(x, 0.75))}
  
  
  summary_cluster <- final.data %>% 
    group_by(ClusterId) %>% 
    summarise_each(funs(pt25, median, pt75))
  
  median_cluster <- final.data %>% 
    group_by(ClusterId) %>% 
    summarise_each(funs(median)) 
  
  count_cluster <- final.data %>% 
    group_by(ClusterId) %>% 
    summarise(count = n()) 
  
  
  
  summary_cluster.final.median <- inner_join(median_cluster,count_cluster)
  
  summary_cluster.final.quantile <- inner_join(summary_cluster,count_cluster)
  
  
  final.object <- list(summary_cluster.final.median,summary_cluster.final.quantile)
  
  return(final.object)
  
}

