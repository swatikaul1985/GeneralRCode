
#Function to process subscription day level data to customer day level with user specific transformations and aggregations



Pull_data <- function(Startdate,Enddate,teleTableNameObject,SnapshottableObject, pairWiseAggFunc.SubToCUst,Dim.level,day,month,Var.list) 

{


# latest customer to subscriptionguid mapping

  
#
  
    
    Sub.Cust.mapping <- SnapshottableObject
   
    
    Tele.data  <- teleTableNameObject
   
    

names(Tele.data) <- tolower(names(Tele.data))

names(Sub.Cust.mapping) <- tolower(names(Sub.Cust.mapping))

# mapping daily telemetry data to customerid

Tele.data$subscriptionguid <- toupper(Tele.data$subscriptionguid)

Sub.Cust.mapping$subscriptionguid <- toupper(Sub.Cust.mapping$subscriptionguid)


Tele.data.cust <- inner_join(Sub.Cust.mapping , Tele.data , by = c("subscriptionguid" = "subscriptionguid"))

names(Tele.data.cust) <- tolower(names(Tele.data.cust))

saveRDS(Tele.data.cust,paste0(ObjectSpace,"\\Tele.data.cust.daily.rds"))

print("sucessfully computed Tele.data.cust")

# aggregate time series data at customer day level

source(paste0(rcoderepo ,"\\AggregateSubToCustDaily.R"))


Final.cust.daily <- aggSubToCust(Tele.data.cust,Dim.level,day,month,Var.list)


print("sucessfully computed Final.cust.daily")

rm(Sub.Cust.mapping)

rm(Tele.data)


return(Final.cust.daily)

}


