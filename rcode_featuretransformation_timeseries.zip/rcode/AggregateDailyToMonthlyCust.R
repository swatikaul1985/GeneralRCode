
# aggregating non time series type of variables from daily to monthly at customer level 


aggDailyMonthly <- function(Tele.data.cust.daily,pairWiseAggFunc.DayToMonth,Dim.level,date.var.list,Enddate){ # Tele.data.cust.daily data frame at customer daily level, npairWiseAggFunc.DayToMonth = list of fields to be aggregated at customer month level, Dim.level = customer id or any other dimension
 
   
  

  # Stop the clock
  ptm = proc.time() 
  
  # aggregating non time series type of variables by different functions
  
  cl = makeCluster(3)
  registerDoSNOW(cl)
  cat(paste(getDoParWorkers(),": Threads intiated!"))
  
  
  Tele.data.cust.monthly <- 
    
    foreach(j=1:length(pairWiseAggFunc.DayToMonth), .combine='cbind')  %dopar% {
      
      require(dplyr)
      var <- pairWiseAggFunc.DayToMonth[[j]][1]
      
      fun <- get(pairWiseAggFunc.DayToMonth[[j]][2]);  
      #a %>% select(which(names(a) %in% c(Dim.level,day,var))) %>% group_by(1,2) %>% summarise( assign(paste0(var,"_",pairWiseAggFunc.SubToCUst[[j]][2]) , fun(names(a)[names(a) %in% c(var)])))
      Tele.data.cust.daily %>% select(which(names(Tele.data.cust.daily) %in% c(Dim.level,var))) %>% group_by(cloudcustomerguid)%>% summarise_each(  funs(fun))
      #a %>% select(which(names(a) %in% c(Dim.level,day,var))) %>% group_by(names(a)[names(a) %in% c(Dim.level)],names(a)[names(a) %in% c(day])%>% summarise_each(  funs(fun))
    }
  
  
  Tele.data.cust.monthly <- Tele.data.cust.monthly[, unique(colnames(Tele.data.cust.monthly))]
  
  stopCluster(cl)
  
  #saveRDS(Tele.data.cust.monthly,"E:\\SWKAUL\\TFS\\Data Sciences\\Workload Clustering - Template\\R Scripts\\clustering library\\R objects\\Tele.data.cust.monthly.rds")
  
  
  # Stop the clock
  proc.time() - ptm
  
  
  if(length(date.var.list) > 0)  { 
  
  source(paste0(rcoderepo ,"\\daySinceDate.R"))
  
  
  a <- Tele.data.cust.monthly %>% select(which(names(Tele.data.cust.monthly) %in% date.var.list ))
  b <- Tele.data.cust.monthly %>% select((which(!(names(Tele.data.cust.monthly) %in% date.var.list ))))
  

  
  a.star <- as.data.frame(apply(a,2,daySinceDate,reference_date = Enddate))
  
  Tele.data.cust.star <- cbind(b,a.star)
  rm(a,b)
  
  return(Tele.data.cust.star)
} else
    {return(Tele.data.cust.monthly)}
  
  
  # creating ratio type features for weighted CPU utilization
  
  
  
  #saveRDS(Tele.data.cust.star,paste0(ObjectSpace,"\\Tele.data.cust.monthly.nonTS.final.rds"))
  
  
  
}
